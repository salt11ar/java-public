package com.example.postgres.springbootpostgresdocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootPostgresDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootPostgresDockerApplication.class, args);
	}

}

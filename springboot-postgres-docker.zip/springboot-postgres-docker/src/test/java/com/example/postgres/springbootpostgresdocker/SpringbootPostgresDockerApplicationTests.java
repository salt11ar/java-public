package com.example.postgres.springbootpostgresdocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootPostgresDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
